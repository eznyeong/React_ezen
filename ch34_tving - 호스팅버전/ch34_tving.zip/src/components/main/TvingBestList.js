import React from 'react';

//티빙TOP20 전체 리스트를 보여주는 프레젠테이셔널 컴포넌트
function TvingBestList() {
    return (
        <div>
            
        </div>
    );
}

export default TvingBestList;