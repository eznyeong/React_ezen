import React from 'react';

//리스트들이 로딩중일 때 보여질 프레젠테이셔널 컴포넌트
function LoadingList() {
    return (
        <div>
            
        </div>
    );
}

export default LoadingList;