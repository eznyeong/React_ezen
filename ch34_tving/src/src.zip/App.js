import React from 'react';
import { Routes, Route } from 'react-router-dom';
//자손컴포넌트 호출
import Header from './components/common/Header';
import Footer from './components/common/Footer';
import MainPage from './pages/MainPage';
import TvingBestPage from './pages/TvingBestPage';

//스타일지정 - 공통 CSS작성 - createGlobalStyle컴포넌트 사용
import styled, { createGlobalStyle } from 'styled-components';

//스타일컴포넌트는 첫글자가 대문자
const GlobalStyle = createGlobalStyle`
  *{ padding: 0;  margin: 0; color: #fff; font-family: 'Noto Sans KR', sans-serif; box-sizing: border-box; }
  body { background: #000; }
  li{ list-style: none; }
  a{ text-decoration: none; }
`;

const BodyBlock = styled.div`
  width: 100%; overflow: hidden;
`;


function App() {
  return (
    <BodyBlock>
      <GlobalStyle />
      {/* 페이지 이동이 없을 header지정 */}
      <Header />
      <Routes>
        {/* 페이지 이동이 것은 이쪽에 처리 */}
        <Route path="/" element={<MainPage />} />
        <Route path="/tvingbest/:id" element={<TvingBestPage />} />
      </Routes>
      {/* 페이지 이동이 없을 footer지정 */}
      <Footer />
    </BodyBlock>
  );
}

export default App;