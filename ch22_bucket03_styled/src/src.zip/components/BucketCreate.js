import React, { useState } from 'react';
import '../sass/bucketcreate.scss';
import { MdAdd } from "react-icons/md";

//입력폼 컴포넌트
function BucketCreate({value, onDataChange, onSubmit}) {
    //활성/비활성관련 state선언 - 다른 컴포넌트에서 사용하지 않으므로 해당 컴포넌트에 선언
    const [open, setOpen] = useState(false); //처음엔 열려 있지 않으므로 false

    //클릭이벤트를 통해 토글함수 선언
    const onToggle = () => setOpen(!open);

    return (
        <>
            {/* 활성화상태는 CSS에서 적용돼야 하므로 클래스로 처리 */}
            <div className={ open ? "createform active" : "createform" }>
                {/* submit이벤트는 form태그만 갖고 있음 */}
                <form onSubmit={onSubmit}>
                    {/* 폼태그 안에 input태그가 하나면 엔터처리시 submit이벤트가 적용 */}
                    <input
                        type="text"
                        placeholder="추가할 버킷리스트를 입력 후, Enter를 누르세요."
                        value={value}
                        onChange={onDataChange}
                    />
                </form>
            </div>
            <div className="circlebox" onClick={onToggle}>
                <MdAdd />
            </div>
        </>
    );
}

export default BucketCreate;